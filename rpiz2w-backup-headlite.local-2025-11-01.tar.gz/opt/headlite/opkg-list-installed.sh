#!/bin/ash

/bin/opkg list-installed; /bin/opkg list-installed > /etc/opkg.cache
