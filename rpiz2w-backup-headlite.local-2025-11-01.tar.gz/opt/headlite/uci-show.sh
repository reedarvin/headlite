#!/bin/ash

/sbin/uci show; /sbin/uci show > /opt/headlite/uci-current.uci
