#!/bin/ash

/usr/bin/tcpdump -D
