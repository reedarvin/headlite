#!/bin/ash

cd /etc/ssl

openssl req -x509 -nodes -days 1825 -newkey rsa:2048 -keyout mycert.key -out mycert.crt -config myconfig.conf

/etc/init.d/uhttpd restart