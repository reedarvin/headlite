#!/bin/ash

/usr/bin/tcpdump $1 $2 -A -nn -s0 -v '(ether[20:2]=0x2000 or ether[12:2]=0x88cc)' & sleep 10; kill $!;
