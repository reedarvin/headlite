#!/bin/sh

# Restart services
# service log restart; service network restart
# service dnsmasq restart; service firewall restart
 
# Log and status
logread; netstat -l -n -p | grep -e dnsmasq
 
# Runtime configuration
pgrep -f -a dnsmasq
ip address show; ip route show table all
ip rule show; ip -6 rule show; nft list ruleset
head -v -n -0 /etc/resolv.* /tmp/resolv.* /tmp/resolv.*/*
 
# Persistent configuration
uci show network; uci show wireless; uci show dhcp; uci show firewall
