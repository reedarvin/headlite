#!/bin/ash

/usr/bin/tcpdump $1 $2 -A -nn -s0 -v 'port 67 or port 69' & sleep 10; kill $!;
