#!/bin/ash

/usr/bin/tcpdump $1 $2 -A -nn -s0 -v 'arp' & sleep 10; kill $!;
